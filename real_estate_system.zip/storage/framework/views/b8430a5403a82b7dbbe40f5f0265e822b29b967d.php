<?php 

?>
<?php $__env->startSection('title', 'Buy'); ?>



  <?php $__env->startSection('content'); ?>
    
    <header id="home" class="home">
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.navbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    </header>

    <section class="page-header" style="background:url(<?php echo e(URL('storage/page-header.jpg')); ?>)">
      <div class="header-wrapper container">
        <h2>Property Lists</h2>
        <ul>
          <li><a href="/">Home</a></li>
          <li>></li>
          <li><a href="<?php echo e(URL('buy')); ?>" class="active-page">Property Lists</a></li>
        </ul>  
      </div>
    </section>

    <section id="listing-page-container">
        <div class="container">
          <div class="row"> 
            <div class="col-md-8 left-col">
                
                
                <?php $__empty_1 = true; $__currentLoopData = $property; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="house">
                    <div class="house-img" style="background-image: url(<?php echo e(URL('uploads/new_property'). '/' .$prop['property_gallery']['featured_img']); ?>);">
                        
                        <?php if($prop->is_featured == 1): ?>
                          <div class="property-featured">Featured</div>
                        <?php endif; ?>
                        <div class="property-for-sell"><?php echo e($prop->property_status); ?> </div>
                        <div class="listing-property-user">
                        <?php if($prop->user->images != null): ?>
                          <img class="listing-property-user-img" src="<?php echo e(URL('uploads/profile_pic'). '/' .$prop->user->images); ?>">
                        <?php else: ?>
                          <img class="listing-property-user-img" src="<?php echo e(URL('uploads/profile_pic/businessman.png')); ?>" alt="?">
                        <?php endif; ?>
                        </div>

                    </div>
                    <div class="house-info">
                        <h3><?php echo e($prop->location['street_address']); ?></h3>

                        <div class="price">
                          <?php if($prop['property_status'] == 'rent'): ?>
                            <small class="previous-price">₱<?php echo e($prop->property_before_price); ?>/mo</small>
                            <p class="listing-price-monthly">₱<?php echo e($prop->property_after_price); ?>/mo</p>
                          <?php else: ?>
                          <small class="previous-price">₱<?php echo e($prop->property_before_price); ?></small>
                          <p class="listing-price-monthly">₱<?php echo e($prop->property_after_price); ?></p>
                          <?php endif; ?>
                        </div>
                        
                        <a href="buy/<?php echo e($prop->property_name_slug); ?>" class="listing-price-view" data-toggle="tooltip" data-placement="top" title="Quick View!">
                            <i class="fa-solid fa-eye"></i>
                        </a>
                    </div>

                    <div class="house-info2">
                      <p><i class="uil uil-bed mr-1"></i><?php echo e($prop->property_bed); ?> Bed</p>
                      <p><i class="uil uil-ruler-combined"></i><?php echo e($prop->property_size); ?> sqft</p>
                      <p><i class="uil uil-bath"></i><?php echo e($prop->property_bath); ?> Bath</p>
                      
                      <p><i class="uil uil-shovel"></i><?php echo e(Str::limit($prop->property_year_built, 4, '')); ?> Year Built</p>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                  <h2 class="result">No Property Listed!</h2>
                <?php endif; ?>
                


        </div>
        <div class="col-md-4 right-col">
          <div class="sidebar">

            <h2>Featured Property</h2>
            <hr class="line1">
            <hr class="line2">

            <?php $__empty_1 = true; $__currentLoopData = $featured_prop; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="sidebar-featured-prop">
              <?php if($f->property_status == "rent"): ?>
              <a href="<?php echo e('rent/' .$f->property_name_slug); ?>">
                <img src="<?php echo e(URL('uploads/new_property'). '/' .$f->property_gallery['featured_img']); ?>" alt="">
              </a>
              <?php else: ?>
              <a href="<?php echo e('buy/' .$f->property_name_slug); ?>">
                <img src="<?php echo e(URL('uploads/new_property'). '/' .$f->property_gallery['featured_img']); ?>" alt="">
              </a>
              <?php endif; ?>
              <div class="featured-prop-wrapper">
                <h3><?php echo e($f->property_type); ?></h3>
                <p>
                  <i class="uil uil-map-marker-alt"></i> <?php echo e(Str::limit($f->location['street_address'], 45, '...')); ?>

                </p>
              </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                ?
            <?php endif; ?>


            <h2 class="recently-added-h2">For Rent Property</h2>
            <hr class="line1">
            <hr class="line2">

            <?php $__empty_1 = true; $__currentLoopData = $rent_property_sidebar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rent_sidebar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <div class="sidebar-featured-prop">
                <a href="<?php echo e('rent/' .$rent_sidebar->property_name_slug); ?>">
                  <img src="<?php echo e(URL('uploads/new_property'). '/' .$rent_sidebar->property_gallery['featured_img']); ?>" alt="">
                </a>
                <div class="featured-prop-wrapper">
                  <h3><?php echo e($rent_sidebar->property_type); ?></h3>
                  <p>
                    <i class="uil uil-map-marker-alt"></i> <?php echo e(Str::limit($rent_sidebar->location['street_address'], 45, '...')); ?>

                  </p>
                </div>
              </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              ?
            <?php endif; ?>

          </div>
        </div>
        </div>

        <div class="row">
          <div class="col-5">
            <p class="font-weight-bold">Showing <?php echo e($property->firstItem()); ?> - <?php echo e($property->lastItem()); ?> of <?php echo e($property->total()); ?></p>
          </div>
          <div class="col-7 pagination-wrapper">
              <?php echo e($property->onEachSide(1)->links()); ?>      
          </div>
        </div>
      </div>
    </section>

<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    
<?php $__env->stopSection(); ?>

   
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\real-estate-web\resources\views/buy.blade.php ENDPATH**/ ?>