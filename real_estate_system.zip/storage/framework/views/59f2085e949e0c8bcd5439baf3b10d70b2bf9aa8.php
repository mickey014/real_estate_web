<footer id="contact">
    <div class="container">
      
      <div class="row footer-bottom">
        <div class="col-sm-12 col-md-4 footer-logo">
          <h4>Kabahayan</h4>
          <p>© 2022 - kabahayan,<br>All Right Reserved</p>
        </div>
        <div class="col-sm-3 col-md-2 footer-column">
          <h5>Quick Links</h5>
          <a href="#">About</a>
          <a href="#">Team</a>
          <a href="#">Services</a>
          <a href="#">Contact Us</a>
        </div>          
        <div class="col-sm-3 col-md-2 footer-column footer-product">
          <h5>PRODUCT</h5>
          
          
        </div>
        <div class="col-sm-3 col-md-2 footer-column">
          <h5>SERVICES</h5>
          <a href="<?php echo e(URL('/rent')); ?>">Renting</a>
          <a href="<?php echo e(URL('/buy')); ?>">Selling</a>
          
        </div>
      </div>
    </div>
</footer><?php /**PATH C:\wamp64\www\real-estate-web\resources\views/components/footer.blade.php ENDPATH**/ ?>