<?php if(isset($user_info)): ?>
  <div class="text-danger" id="navbar-user-name" style="display: none;">
    <?php echo e($user_info->name); ?>

  </div>
<?php endif; ?>
<?php $__env->startSection('title', 'Agent Login'); ?>



  <?php $__env->startSection('content'); ?>

  <header id="home" class="home" style="margin-bottom: 4rem;">
    <?php echo $__env->make('partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </header>
    <section class="agent-login-box" id="agent-login-box">
        <div class="form">
        <h1>Logged in as Agent</h1>
        <form class="login-form">
            <input type="text" placeholder="Username"/>
            <input type="password" placeholder="Password"/>
            <button>login</button>
            <p class="message">Not registered?<br><a href="<?php echo e(URL('/agent/register')); ?>">Create an account</a></p>
        </form>
        </div>
    </section>

  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\real-estate-web\resources\views/agent/register.blade.php ENDPATH**/ ?>