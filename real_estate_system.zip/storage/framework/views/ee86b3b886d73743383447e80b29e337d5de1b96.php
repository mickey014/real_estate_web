<!------------------------------------------------ HEADER SECTION -->
<header id="home" class="home">
  
  <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.navbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
  
  <div class="hero">
    <div class="container-fluid p-0">
      <div class="hero-wrapper">
        <div class="title p-4 wow fadeIn" data-wow-delay="0.1s">
          <!-- Hero Title -->
          <h1 class="hero-h1">Find A <span class="text-main-color">Perfect Home</span> To Live With Your Family</h1>
          <p class="mt-4">With a robust selection of popular properties on hand, as well <br/>as leading properties from real estate experts.</p>
            <!-- Search -->
            
            <a href="buy" class="btn get-started py-3 px-5 animated fadeIn">Get Started</a> 
        </div>
        <div class="hero-image wow fadeIn" style="background-image: url(<?php echo e(URL('storage/hero-img.jpg')); ?>);" data-wow-delay="0.1s">
        </div>
         <!-- Search Start -->
    <div class="container-fluid home-search-property flex-center wow fadeIn" data-wow-delay="0.1s">
      <div class="container">
          <form method="GET" action="<?php echo e(route('search')); ?>" class="search_by row g-2" role="search">
             
              <div class="col-md-3">
                  
                  <select class="form-select border-0 p-3 w-100" name="status">
                    <option value="buy">Buy</option>
                    <option value="rent">Rent</option>
                </select>
              </div>
              <div class="col-md-3">
                  <select class="form-select border-0 p-3 w-100" name="type">
                      <option selected value="all">Any</option>
                      <?php $__empty_1 = true; $__currentLoopData = $property_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                      <option value="<?php echo e(Str::lower($type['name'])); ?>"><?php echo e($type['name']); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        ?
                      <?php endif; ?>
                  </select>
              </div>
              <div class="col-md-4">
                <input type="text" class="typeahead form-control border-0 search-property-input" placeholder="Location">
              </div>
                
              <div class="col-md-2">
                  <button type="submit" class="btn btn-search-property w-100">Search</button>
              </div>
          </form>
      </div>
  </div>
<!-- Search End -->
      </div>
    </div>
  </div>
  
</header>

<?php /**PATH C:\wamp64\www\real-estate-web\resources\views/partials/header.blade.php ENDPATH**/ ?>