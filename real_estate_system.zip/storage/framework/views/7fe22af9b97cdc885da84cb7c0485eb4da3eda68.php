<?php $__env->startSection('title', 'About'); ?>


<?php $__env->startSection('content'); ?>

<header id="home" class="home">
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.navbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
</header>

<section class="about-us" style="background-image: url(<?php echo e(URL('storage/about-us.jpg')); ?>);">
    <div class="inner-container" >
        <h1>About Us</h1>
        <p class="text">
            Lorem ipsum dolor sit amet consectetur, adipisicing elit. Minima eius pariatur itaque, vero sapiente nesciunt facere ad magni dignissimos quidem, quod sunt deleniti asperiores eaque est reprehenderit iste incidunt quos repellendus expedita distinctio. Impedit, ex ipsam?
        </p>
        <div class="skills">
            <span>Renting</span>
            <span>Selling</span>
            <span>Buying</span>
        </div>
    </div>
</section>

<?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\real-estate-web\resources\views/about-us.blade.php ENDPATH**/ ?>