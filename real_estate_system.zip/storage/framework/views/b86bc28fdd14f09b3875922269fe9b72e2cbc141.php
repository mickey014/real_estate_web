<?php $__env->startSection('title', 'Reset Password'); ?>

<?php $__env->startSection('content'); ?>


<header id="home" class="home">
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.navbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
</header>


<section class="container forgot-password">
    <h1 class="text-center">Password Reset</h1>
    <div class="row justify-content-center align-items-center">

        <div class="col-md-6 col-md-offset">
            <form action="<?php echo e(route('auth.resetPassword')); ?>" class="card mt-4" method="POST" id="reset-password">
                <?php echo csrf_field(); ?>
                <div class="card-body pb-0">
                    <div id="reset-errors"></div>
                    
                    <input type="hidden" name="id" value="<?php echo e($user[0]['id']); ?>">
                    <div class="form-group reset-wrapper-pass">
                        <label for="password">Password:</label>
                        <input class="form-control reset-pass" type="password" id="password" name="password">
                        <i class="fa-regular fa-eye reset-toggle-password"></i>
                    </div>
                    <div class="form-group reset-wrapper-cpass">
                        <label for="confirm-password">Confirm Password:</label>
                        <input class="form-control reset-cpass" type="password" id="cpassword" name="cpassword">
                        <i class="fa-regular fa-eye reset-toggle-cpassword"></i>
                    </div>

                </div>
                <div class="card-footer">
                    <button class="btn bg-primary-color" type="submit" id="btn-pword-reset">Submit</button>
                </div>
            </form>
            
        </div>
        
        
    </div>
</section>
<?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    $(document).ready(function(e) {

        let reset_password;

        $('.reset-toggle-password').click(function() {
            $(this).toggleClass("fa-eye fa-eye-slash");
            var input = $(".reset-pass");
            if (input.attr("type") === "password") {
            input.attr("type", "text");
            } else {
            input.attr("type", "password");
            }
        });

        $('.reset-toggle-cpassword').click(function() {
            $(this).toggleClass("fa-eye fa-eye-slash");
            var input = $(".reset-cpass");
            if (input.attr("type") === "password") {
            input.attr("type", "text");
            } else {
            input.attr("type", "password");
            }
        });
        
        $('#reset-password').submit(function(e) {
            e.preventDefault();
    
            $.ajax({
            url: $(this).attr('action'),
            method: 'post',
            data: $(this).serialize(),
            dataType: 'json',    
            success: function(res) {
                if(res.status == 400) {
                    
                    $('#reset-errors').html('');
                    $.each(res.errors, function (key, err_value) {
                    //   toastr.error(err_value) 
                        $('#reset-errors').append('<p class="text-danger p-0 m-0">'+err_value+'</p>');
                    });  
                     
                  
                } else if(res.status == 200) {
                    $('#reset-errors').html('');
                    if ( !$('#reset-errors').children().length > 0 ) {
                        $('#btn-pword-reset').prop('disabled',true);
                        $('#btn-pword-reset').addClass('not-allowed');
                        reset_password = bootbox.dialog({
                                message: `<div class="text-center"><i class="fas fa-spin
                                fa-spinner"></i> Loading...</div>`,
                                closeButton: false
                        });
                        setInterval(function() {
                            reset_password.modal('hide');
                            $('#btn-pword-reset').prop('disabled',false);
                            $('#btn-pword-reset').removeClass('not-allowed');
                            $(".reset-pass").val('');
                            $(".reset-cpass").val('');
                        }, 800);

                        setInterval(function() {
                            window.location = '/'
                        }, 900);
                    }
                    
                    
                }
                
            }
            });
        })

        

        
        
    });
    
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\real-estate-web\resources\views/reset-password.blade.php ENDPATH**/ ?>