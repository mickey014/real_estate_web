


  <nav class="animate navs">
    <div class="container-fluid">
      <div class="logo left pl-2 flex-center">
        <!-- Logo -->
        <a href="#home" class="nav-links">DEV</a>
      </div>
      <div class="menu-button hide right pointer">
        <span></span>
        <span></span>
        <span></span>
      </div>
      <div class="menu left">
        <div class="page-menu left">
          <li><a href="/" class="nav-links">Home</a></li>
          <li><a href="<?php echo e(URL('/listings')); ?>" class="nav-links">Listing</a></li>
          <li><a href="#works" class="nav-links">Rent</a></li>
          <li><a href="<?php echo e(URL('/agent/login')); ?>" class="nav-links">Agent</a></li>
          <div class="nav-pages">
            <ul class="navbar-nav">
                <li class="nav-item" id="nav-pages-item">
                  <a class="nav-links dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" >
                    Pages
                  </a>
                  <div class="dropdown-menu dropdown-menu-right py-0" aria-labelledby="navbarDropdownMenuLink">
                    <a class="dropdown-item px-4" href="#">About Us</a>
                    <a class="dropdown-item px-4" href="#">Team</a>
                    <a class="dropdown-item px-4" href="#">Services</a>
                    <a class="dropdown-item px-4" href="#">Contact Us</a>
                  </div>
              </li>   
            </ul>
          </div>

        </div>
        <div class="registration nav-user-profile-pull-right">

          <?php if(!Session::has('loggedinUser')): ?> 
          <div class="join-us">
            <!-- Join Us Button -->
            <li class="pointer animate">
              <a @click="open = !open" 
              class="join-us-link" href="javascript:void(0)">
                <i class='bx bx-user'></i>Join Us
              </a>
			      </li>

          </div>

          <?php else: ?>
          <div class="getting-started">
            <!-- Get Started Button -->
            <li class="main-btn pointer text-center">
              <a href="#">
                <img class="add-listing-icon" src="<?php echo e(URL('storage/add_home_white.png')); ?>" alt="">
                Add Listing
              </a>
            </li>
          </div>

          <div class="nav-user-profile" id="navbar-list-4">
            <ul class="navbar-nav">
                <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" >
                  <img class="user-profile-icon" src="<?php echo e(URL('storage/man.png')); ?>" alt="" data-toggle="tooltip" data-placement="bottom" title="Hit me!">
                  
                </a>
                <div class="dropdown-menu dropdown-menu-right py-0 pt-4" aria-labelledby="navbarDropdownMenuLink">
                  
                  <a href="#" class="dropdown-item-user-name px-4">
                    <img class="user-profile-icon" src="<?php echo e(URL('storage/man.png')); ?>" alt="" >
                    <span id="navbar-nav-user-profile"></span>
                    
                  </a>

                  <hr class="px-4 mb-0">
                  
                  
                  <a class="dropdown-item px-4 d-flex align-items-center" href="#"><i class='bx bxs-dashboard'></i> Dashboard</a>
                  <a class="dropdown-item px-4 d-flex align-items-center" href="#"><i class='bx bxs-user-detail'></i> Edit Profile</a>
                  <a class="dropdown-item px-4 d-flex align-items-center" href="#"><i class='bx bx-cog' ></i> Settings & Privacy</a>
                  <a class="dropdown-item px-4 d-flex align-items-center" href="<?php echo e(route('auth.logoutUser')); ?>"><i class='bx bx-exit'></i> Logout</a>
                </div>
              </li>   
            </ul>
          </div>
          
          <?php endif; ?>

        </div>
      </div>
    </div>
  </nav>

  <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.navbar-login-modal','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('navbar-login-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>



<?php /**PATH C:\wamp64\www\real-estate-web\resources\views/partials/navbar.blade.php ENDPATH**/ ?>