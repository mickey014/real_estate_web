<footer id="contact">
    <div class="container">
      
      <div class="row footer-bottom">
        <div class="col-sm-12 col-md-4 footer-logo">
          <h4><?php echo e(config('app.name')); ?></h4>
          <p>© <?php echo e(date("Y")); ?> - <?php echo e(config('app.name')); ?>,<br>All Right Reserved</p>
        </div>
        <div class="col-sm-3 col-md-2 footer-column">
          <h5>Quick Links</h5>
          <a href="#">About</a>
          <a href="#">Team</a>
          <a href="#">Services</a>
          <a href="#">Contact Us</a>
        </div>          
        <div class="col-sm-3 col-md-2 footer-column">
          <h5>PRODUCT</h5>
          <?php $__empty_1 = true; $__currentLoopData = $property_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <a href="javascript:;"><?php echo e($type->name); ?></a>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            ?
          <?php endif; ?>
          
        </div>
        <div class="col-sm-3 col-md-2 footer-column">
          <h5>SERVICES</h5>
          <a href="<?php echo e(URL('/rent')); ?>">Renting</a>
          <a href="<?php echo e(URL('/buy')); ?>">Selling</a>
          
        </div>
      </div>
    </div>
</footer><?php /**PATH C:\wamp64\www\real-estate-web\resources\views/partials/footer.blade.php ENDPATH**/ ?>