@section('title', 'Team')
@extends('layouts.app')


@section('content')

<header id="home" class="home">
    <x-navbar />
</header>

<section class="swiper mySwiper" id="our-team">

    <div class="swiper-wrapper">

      <div class="card swiper-slide">
        <div class="card__image">
          <img src="{{ url('storage/mayee.jpg') }}" alt="card image">
        </div>

        <div class="card__content">
          <span class="card__title">Head team</span>
          <span class="card__name">Mayee Solijon Cruz</span>
          <p class="card__text">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sit veritatis labore provident non tempora odio est sunt, ipsum</p>
          <button class="card__btn">View More</button>
        </div>
      </div>

      <div class="card swiper-slide">
        <div class="card__image">
          <img src="{{ url('storage/kirk.jpg') }}" alt="card image">
        </div>

        <div class="card__content">
          <span class="card__title">Programmer</span>
          <span class="card__name">Kirk Anthony Mendoza</span>
          <p class="card__text">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sit veritatis labore provident non tempora odio est sunt, ipsum</p>
          <button class="card__btn">View More</button>
        </div>
      </div>

      <div class="card swiper-slide">
        <div class="card__image">
          <img src="{{ url('storage/ronn.jpg') }}" alt="card image">
        </div>

        <div class="card__content">
          <span class="card__title">Web Developer</span>
          <span class="card__name">Ronald Aguilar Gardoce</span>
          <p class="card__text">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sit veritatis labore provident non tempora odio est sunt, ipsum</p>
          <button class="card__btn">View More</button>
        </div>
      </div>

      <div class="card swiper-slide">
        <div class="card__image">
          <img src="{{ url('storage/earl.jpg') }}" alt="card image">
        </div>

        <div class="card__content">
          <span class="card__title">Web Designer</span>
          <span class="card__name">Earl Junicel Guardiana</span>
          <p class="card__text">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sit veritatis labore provident non tempora odio est sunt, ipsum</p>
          <button class="card__btn">View More</button>
        </div>
      </div>
      
      <div class="card swiper-slide">
        <div class="card__image">
          <img src="{{ url('storage/james.jpg') }}" alt="card image">
        </div>

        <div class="card__content">
          <span class="card__title">Mobile App Developer</span>
          <span class="card__name">James Tirariray</span>
          <p class="card__text">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sit veritatis labore provident non tempora odio est sunt, ipsum</p>
          <button class="card__btn">View More</button>
        </div>
      </div>

    </div>
  </section>

@include('partials.footer')
    
@endsection