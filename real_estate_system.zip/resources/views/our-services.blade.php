@section('title', 'Services')
@extends('layouts.app')

@section('content')

<header id="home" class="home">
    <x-navbar />
</header>

<section class="our-services">
    
      <h2 class="section-heading">Our Services</h2>
    
    <div class="row">
      <div class="column">
        <div class="card">
          <div class="icon-wrapper">
            <i class="fa-solid fa-calendar-check"></i>
          </div>
          <h3>Appointment</h3>
          <p>
            a salesperson who works for a real estate agency.
          </p>
        </div>
      </div>
      <div class="column">
        <div class="card">
          <div class="icon-wrapper">
            <i class="fa-solid fa-handshake"></i>
          </div>
          <h3>Buy and Sell</h3>
          <p>
            an agreement between the buyer and the seller whereby the seller has the duty to transfer 
            the ownership of property to the buyer and the buyer pays the price of the property to the seller.
          </p>
        </div>
      </div>
      <div class="column">
        <div class="card">
          <div class="icon-wrapper">
            <i class="fa-solid fa-key"></i>
          </div>
          <h3>Renting</h3>
          <p>
            property used or occupied by any tenant for which rent is paid to a landlord.
          </p>
        </div>
      </div>
      <div class="column">
        <div class="card">
          <div class="icon-wrapper">
            <i class="fas fa-truck-pickup"></i>
          </div>
          <h3>Service Heading</h3>
          <p>
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Quisquam
            consequatur necessitatibus eaque.
          </p>
        </div>
      </div>
      <div class="column">
        <div class="card">
          <div class="icon-wrapper">
            <i class="fas fa-broom"></i>
          </div>
          <h3>Service Heading</h3>
          <p>
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Quisquam
            consequatur necessitatibus eaque.
          </p>
        </div>
      </div>
      <div class="column">
        <div class="card">
          <div class="icon-wrapper">
            <i class="fas fa-plug"></i>
          </div>
          <h3>Service Heading</h3>
          <p>
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Quisquam
            consequatur necessitatibus eaque.
          </p>
        </div>
      </div>
    </div>
    
  </section>
  @include('partials.footer')


    
@endsection